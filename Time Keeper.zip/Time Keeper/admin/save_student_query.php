
	<?php
	require_once 'connect.php';
	if(ISSET($_POST['save'])){
		$user_no = $_POST['user_no'];
		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$q_checkadmin = $conn->query("SELECT * FROM `late` WHERE `user_no` = '$user_no'") or die(mysqli_error());
		$v_checkadmin = $q_checkadmin->num_rows;
		if($v_checkadmin == 1){
			echo '
				<script type = "text/javascript">
					alert("Barcode is already taken");
					window.location = "student.php";
				</script>
			';
		}else{
			
			$conn->query("INSERT INTO `late` 	VALUES('', '$user_no','$firstname','$middlename', '$lastname','OFFLINE')") or die(mysqli_error());
			
						echo '
				<script type = "text/javascript">
					alert("Saved Record");
					window.location = "student.php";
				</script>
			';
	}		
	}