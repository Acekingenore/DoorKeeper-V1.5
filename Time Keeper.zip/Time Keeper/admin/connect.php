<?php
	$conn = new mysqli('localhost', 'root', '','timekeeper') or die("Database Connection Failed");