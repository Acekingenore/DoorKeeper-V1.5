<?php
	require_once 'connect.php';
	$conn->query("DELETE FROM `timein` WHERE `id` = '$_REQUEST[id]'") or die(mysqli_error());
	header('location:c101.php');