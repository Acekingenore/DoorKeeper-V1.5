<!DOCTYPE html>
<?php
	require_once 'validator.php';
	require_once 'account.php'; 
?>
<html lang = "eng">
	<head>
		<title>TimeKeeper v1.0</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<link rel = "stylesheet" href = "css/bootstrap.css" />
		<link rel = "stylesheet" href = "css/jquery.dataTables.css" />
	</head>
	<body>
		<nav class = "navbar navbar-inverse navbar-fixed-top">
			<div class = "container-fluid">
				<div class = "navbar-header">
					<p class = "navbar-text pull-right">Time Keeper</p>
				</div>
				<ul class = "nav navbar-nav navbar-right">
					<li class = "dropdown">
						<a href = "#" class = "dropdown-toggle" data-toggle = "dropdown"><i class = "glyphicon glyphicon-user"></i> <?php echo htmlentities($admin_name)?> <b class = "caret"></b></a>
						<ul class = "dropdown-menu">
							<li><a href = "logout.php"><i class = "glyphicon glyphicon-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</nav>
		<div class = "container-fluid" style = "margin-top:70px;">
			<ul class = "nav nav-pills">
				<li><a href = "home.php"><span class = "glyphicon glyphicon-home"></span> Home</a></li>
				<li class = "dropdown active">
					<a class = "dropdown-toggle" data-toggle = "dropdown" href = "#"><span class = "glyphicon glyphicon-book"></span> Records <span class = "caret"></span></a>
					<ul class = "dropdown-menu">
						
						<li><a href = "c101.php"><span class = "glyphicon glyphicon-user"></span>Time Record</a></li>
					</ul>
				</li>
				<li><a href = "barcode/html/BCGcode39.php"><span class = "glyphicon glyphicon-barcode"></span> Barcode</a></li>
				
				<li><a href = "../index.php"target="_blank"><span class = "glyphicon glyphicon-eye-open" ></span> Barcode Scanner</a></li>
			</ul>
			<br />
			<div class = "alert alert-info">Time Record</div>
			<div class = "modal fade" id = "delete" tabindex = "-1" role = "dialog" aria-labelledby = "myModallabel">
				<div class = "modal-dialog" role = "document">
					<div class = "modal-content ">
						<div class = "modal-body">
							<center><label class = "text-danger">Are you sure you want to delete this record?</label></center>
							<br />
							<center><a class = "btn btn-danger remove_id" ><span class = "glyphicon glyphicon-trash"></span> Yes</a> 
							<button type = "button" class = "btn btn-warning" data-dismiss = "modal" aria-label = "No">
							<span class = "glyphicon glyphicon-remove"></span> No</button></center>
						</div>
					</div>
				</div>
			</div>
				
	<div class = "well col-lg-12">				<a href="javascript:print()">
<button>Print</button></a><div class="content" id="content" >	
				<table id = "table" class = "table table-bordered">

					<thead class = "alert-info">
						<tr>
							
							<th>Employee ID</th>
							<th>Employee Details</th>
							<th>Time in</th>
							<th>Time out</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php
					
						$q_time = $conn->query("SELECT * FROM `timein`") or die(mysqli_error());
						while($f_time=$q_time->fetch_array()){	
					?>	
						<tr>
							<td><?php echo $f_time['user_no']?></td>
							<td><?php echo htmlentities($f_time['user_name'])?></td>
							<td><?php echo $f_time['time']?></td>
							<td><?php echo $f_time['out']?></td>
							<td><?php echo date("m-d-Y", strtotime($f_time['date']))?></td>
							
							<td>
							<a class = "btn btn-danger ruser_id" onclick="return confirm('Are You Sure?')"
							href = "c101.php?idx=<?php echo $f_time['id']?>">
							<span class = "glyphicon glyphicon-remove">
							</span></a> 
							<?php
							}
							if(isset($_GET['idx'])){
								$idx=$_GET['idx'];
								$result=$conn->query("DELETE FROM timein WHERE id='$idx'");
								if($result){
									?>
									<script>
									alert('Successful Deleted');
									window.location.href='c101.php';
									</script>
									<?php
								}else{
									?>
									<script>
									alert('Fail To Delete The Student');
									window.location.href='c101.php';
									</script>
									<?php
								}
							}
							?>
						</td>
						</tr>
						
					<?php
						
						echo"
						
						<br>
						<br>
						<br>
						<br>
						"
					?>	
					
					</tbody>
					
				</table>
			</div>
			</div>
		<br>	<br>	<br>	<br>
		</div>
		<div class = "navbar navbar-fixed-bottom alert-warning">
			
		</div>	
	</body>
	<script src = "js/jquery.js"></script>
	<script src = "js/bootstrap.js"></script>
	<script src = "js/jquery.dataTables.js"></script>
	<script type = "text/javascript">
		$(document).ready(function(){
			$('#table').DataTable();
		});
	</script>
	<script type = "text/javascript">
		$(document).ready(function(){
			$('.ruser_id').click(function(){
				$late_id = $(this).attr('name');
				$('.remove_id').click(function(){
					window.location = 'delete_c101.php?id=' + $id;
				});
			});
		});
	</script>
		<script language="javascript">

function print()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=800, height=700, left=500, top=10"; 
  var content_vlue = document.getElementById("content").innerHTML; 
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<title>Equip Ministry</title>');   
   docprint.document.write('<link href="css/style_content.css" rel="stylesheet" type="text/css" media="print"/>');    
   docprint.document.write('<body onLoad="self.print()" style="width: 800px; font-size: 5px; font-family: arial;">');      
   docprint.document.write(content_vlue); 
   docprint.document.write('</body">');      
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
</html>