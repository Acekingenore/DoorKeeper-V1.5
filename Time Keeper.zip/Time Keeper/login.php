<?php
//Code Monster Project HLCC 2018 Time Keeper v1.0
require_once 'admin/connect.php';
if(isset($_POST['search'])){
$student = $_POST['user'];
date_default_timezone_set("Singapore");
$time = date("h:i A",strtotime("+0 HOURS"));
$date = date("M-d-Y");
$q_student = $conn->query("SELECT * FROM `late` WHERE user_no = '$student'") or die(mysqli_error());						
$f_student = $q_student->fetch_array();

	if($f_student['user_no']==$student){
		if($f_student['id']=="OFFLINE"){
			$conn->query("UPDATE `late` SET `id` = 'ONLINE' WHERE `user_no` = '$student'") or die(mysqli_error());
				echo"<h1 style='color:red;'>Time In</h1>";
					$student_name = $f_student['fname']." ".$f_student['mname']." ".$f_student['lname'];
						echo "<h3 class = 'text-muted'>".$student_name." <label class = 'text-info'> Time In at  ".date("h:i A", strtotime($time))." ".$date."</label></h3>";
							$conn->query("INSERT INTO `timein` VALUES('','$student','$student_name','$time','','$date')") or die(mysqli_error());
								
		}elseif($f_student['id']=="ONLINE"){
				$conn->query("UPDATE `late` SET `id` = 'OFFLINE' WHERE `user_no` = '$student'") or die(mysqli_error());	
				echo"<h1 style='color:red;'>Time Out</h1>";
					$student_name = $f_student['fname']." ".$f_student['mname']." ".$f_student['lname'];
						echo "<h3 class = 'text-muted'>".$student_name." <label class = 'text-info'> Time In at  ".date("h:i A", strtotime($time))." ".$date."</label></h3>";
						
							
							$conn->query("UPDATE `timein` SET `out` = '$time' WHERE `user_no` = '$student'") or die(mysqli_error());	
			}
		}else{
			echo"
						<h2 style='color:red;'>
							<span class = 'glyphicon glyphicon-warning-sign'></span></h2>
								<div style='color:red;'><h3>Invalid Barcode ID !</h3></div>";
		}
	}
?>

